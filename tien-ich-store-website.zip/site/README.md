# Tiện Ích Store – Website phụ kiện điện thoại và đồ gia dụng (HTML/CSS/JS thuần)

## Cấu trúc
6 trang .html · css/style.css · js/app.js · js/data.js (dữ liệu sản phẩm và ảnh nền) · robots.txt · sitemap.xml · vercel.json

## Triển khai lên Vercel
1. Đưa thư mục dự án lên GitHub. 2. Vercel → Add New → Project → chọn repo → Deploy.
3. Thay `ten-mien-cua-ban.vercel.app` trong các file .html, sitemap.xml, robots.txt bằng tên miền thật.

## Thêm ảnh, video, đổi ảnh nền
Mở /quan-tri (mật khẩu mặc định `admin123`, đổi ở ADMIN_PASS trong js/app.js).
- Sản phẩm: tải nhiều ảnh từ máy, dán link YouTube hoặc .mp4 cho video.
- Tab "Ảnh nền": tải ảnh hoặc dán link để đổi nền banner trang chủ.
- Bấm "Tải data.js", chép đè vào js/data.js, đẩy lên GitHub: khách sẽ thấy thay đổi.

## Mẹo giữ web nhanh
Ảnh tải từ trang quản trị được nén và nhúng vào data.js. Nếu có nhiều sản phẩm, hãy đặt ảnh vào thư mục img/, video mp4 vào video/ rồi nhập đường dẫn (img/ten.jpg) để file data.js nhẹ.

## Giới hạn
Giỏ hàng, đơn hàng và bản nháp lưu trong trình duyệt. Để nhận đơn về một nơi và quản trị từ xa, cần backend (Supabase, Vercel Postgres/Blob…).
